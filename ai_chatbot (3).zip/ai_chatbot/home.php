<?php
session_start();
if(!isset($_SESSION['username'])){
    header('location:login.php');
}
?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>AI Research Assistant</title>
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
    />
    <link rel="stylesheet" href="styles.css" />
  </head>
  <body>
    <header class="chat-header">
      <div class="header-content">
        <div class="logo-container">
          <div class="logo-icon">
            <i class="fas fa-robot"></i>
          </div>
          <h1>AI Research Assistant</h1>
        </div>
         <a href="logout.php" class='logout_btn'>Logout</a>
      </div>
    </header>
    <main class="chat-container" id="chat-container">
      <div class="welcome-message">
        <div class="welcome-icon">
          <i class="fas fa-robot"></i>
        </div>
        <h2>Hello! I'm your AI Research Assistant</h2>
        <p>
          Ask me anything or upload an image for analysis. I can help with
          research, explanations, and more.
        </p>
      </div>
    </main>
    <footer class="chat-footer">
      <div class="footer-content">
        <div id="image-preview-container" class="hidden">
          <img id="image-preview" class="image-preview" src="#" alt="Preview" />
          <div class="preview-controls">
            <span>Ready to analyze</span>
            <button id="remove-image">
              <i class="fas fa-times"></i> Remove
            </button>
          </div>
        </div>

        <div class="input-container">
          <div class="file-input-wrapper">
            <button class="upload-btn">
              <i class="fas fa-image"></i> Upload Image
            </button>
            <input type="file" id="image-upload" accept="image/*" />
          </div>

          <div class="text-input-wrapper">
            <input
              type="text"
              id="message-input"
              placeholder="Ask me anything..."
            />
            <button id="send-message">
              <i class="fas fa-paper-plane"></i>
            </button>
          </div>
        </div>
        <p class="disclaimer">
          AI Assistant may produce inaccurate information about people, places,
          or facts
        </p>
      </div>
    </footer>

    <script src="script.js"></script>
  </body>
</html>
