// DOM Elements
const chatContainer = document.getElementById("chat-container");
const messageInput = document.getElementById("message-input");
const sendButton = document.getElementById("send-message");
const imageUpload = document.getElementById("image-upload");
const imagePreviewContainer = document.getElementById(
  "image-preview-container"
);
const imagePreview = document.getElementById("image-preview");
const removeImageButton = document.getElementById("remove-image");

// Configuration - Ollama local API
const API_URL = "http://127.0.0.1:11434/api/generate";
const MODEL_NAME = "llama2";

// State
const user = {
  message: "",
  file: {
    data: null,
    mime_type: null,
  },
};

// Event Listeners
// Wire event listeners only if elements exist to avoid runtime errors
if (sendButton) sendButton.addEventListener("click", sendMessage);
if (messageInput)
  messageInput.addEventListener("keypress", (e) => {
    if (e.key === "Enter") sendMessage();
  });
if (imageUpload) imageUpload.addEventListener("change", handleImageUpload);
if (removeImageButton) removeImageButton.addEventListener("click", removeImage);

// Main Functions
async function sendMessage() {
  // Defensive guards in case DOM elements are missing
  user.message = (messageInput && messageInput.value ? messageInput.value : "").trim();
  const imageFile = imageUpload?.files?.[0] ?? null;

  // Check if this is the first message and remove the welcome message
  const welcomeMessage = document.querySelector(".welcome-message");
  if (welcomeMessage) {
    welcomeMessage.remove();
  }

  if (!user.message && !imageFile) return;

  // Clear inputs
  const currentImage = imageFile ? URL.createObjectURL(imageFile) : null;
  if (messageInput) messageInput.value = "";
  if (imageUpload) imageUpload.value = "";
  if (imagePreviewContainer) imagePreviewContainer.classList.add("hidden");

  // Store file data if image is uploaded
  if (imageFile) {
    user.file.data = await readFileData(imageFile);
    user.file.mime_type = imageFile.type;
  }

  // Add user message to chat
  addMessageToChat("user", user.message, currentImage);

  // Generate AI response
  await generateResponse();
}

async function generateResponse() {
  showTypingIndicator();

  try {
    const response = await callAIAPI();
    // Ollama returns the response in 'response' field
    const aiText =
      response?.response ||
      "I didn't understand that. Could you try again?";

    // Format the AI response
    const formattedResponse = formatAIResponse(aiText);
    addMessageToChat("bot", formattedResponse);
  } catch (error) {
    console.error("Error generating response:", error);
    addMessageToChat("bot", `⚠ An error occurred: ${error.message}`);
  } finally {
    hideTypingIndicator();
    scrollToBottom();
  }
}

async function callAIAPI() {
  const requestBody = {
    model: MODEL_NAME,
    prompt: user.message,
    stream: false,
  };

  const requestOptions = {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(requestBody),
  };

  try {
    const response = await fetch(API_URL, requestOptions);
    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.error || `API request failed with status ${response.status}`);
    }
    return await response.json();
  } catch (err) {
    // Re-throw with a clearer message
    throw new Error(err.message || "Failed to call AI API");
  }
}

// Helper Functions
function addMessageToChat(sender, content, imageUrl = null) {
  if (!chatContainer) {
    console.warn("Cannot add message: chat container not found");
    return;
  }

  const messageDiv = document.createElement("div");
  messageDiv.className = `message ${sender}-message`;

  // Create an icon element
  const iconElement = document.createElement("div");
  iconElement.className = "message-icon";
  iconElement.innerHTML =
    sender === "user"
      ? '<i class="fas fa-user"></i>'
      : '<i class="fas fa-robot"></i>';

  // Create a content wrapper
  const contentDiv = document.createElement("div");
  contentDiv.className = "message-content";

  if (imageUrl) {
    const imgElement = document.createElement("img");
    imgElement.src = imageUrl;
    imgElement.className = "image-preview mb-1";
    contentDiv.appendChild(imgElement);
  }

  // For user messages, treat content as plain text to avoid XSS.
  // For bot messages, allow formatted HTML returned by the AI.
  if (sender === "user") {
    const textNode = document.createTextNode(content || "");
    contentDiv.appendChild(textNode);
  } else {
    contentDiv.innerHTML += content || "";
  }
  messageDiv.appendChild(iconElement);
  messageDiv.appendChild(contentDiv);

  const timestamp = document.createElement("div");
  timestamp.className = "message-timestamp";
  timestamp.textContent = new Date().toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit",
  });
  messageDiv.appendChild(timestamp);

  // Append the new message to the chat container
  chatContainer.appendChild(messageDiv);
  scrollToBottom(); // Scroll to the bottom after adding a new message
}

function formatAIResponse(responseText) {
  const lines = responseText
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);
  let html = "";
  let inList = false;

  lines.forEach((line) => {
    const sectionMatch = line.match(/^(\d+)\.\s+(.*)/);
    if (sectionMatch) {
      if (inList) {
        html += "</ul>";
        inList = false;
      }
      html += `<h3>${sectionMatch[1]}. ${sectionMatch[2]}</h3>`;
      return;
    }

    if (/^[-*•]\s+/.test(line)) {
      if (!inList) {
        html += "<ul>";
        inList = true;
      }
      html += `<li>${line.replace(/^[-*•]\s+/, "")}</li>`;
      return;
    }

    if (inList) {
      html += "</ul>";
      inList = false;
    }

    html += `<p>${line}</p>`;
  });

  if (inList) html += "</ul>";
  return html;
}

function showTypingIndicator() {
  const typingDiv = document.createElement("div");
  typingDiv.className = "typing-indicator";

  for (let i = 0; i < 3; i++) {
    const dot = document.createElement("div");
    dot.className = "typing-dot";
    typingDiv.appendChild(dot);
  }

  typingDiv.id = "typing-indicator";
  if (chatContainer) chatContainer.appendChild(typingDiv);
  scrollToBottom(); // Scroll to the bottom when typing indicator is shown
}

function hideTypingIndicator() {
  const typingIndicator = document.getElementById("typing-indicator");
  if (typingIndicator) typingIndicator.remove();
}

function scrollToBottom() {
  if (!chatContainer) return;
  chatContainer.scrollTop = chatContainer.scrollHeight; // Scroll to the bottom
}

async function readFileData(file) {
  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onload = (event) => {
      const result = event?.target?.result || "";
      const parts = result.split(",");
      resolve(parts[1] || "");
    };
    reader.readAsDataURL(file);
  });
}

function handleImageUpload(e) {
  if (!e.target || !e.target.files || e.target.files.length === 0) return;
  const file = e.target.files[0];
  const reader = new FileReader();

  reader.onload = (event) => {
    if (imagePreview) imagePreview.src = event.target.result || "";
    if (imagePreviewContainer) imagePreviewContainer.classList.remove("hidden");
  };

  reader.readAsDataURL(file);
}

function removeImage() {
  if (imagePreview) imagePreview.src = "#";
  if (imageUpload) imageUpload.value = "";
  if (imagePreviewContainer) imagePreviewContainer.classList.add("hidden");
}

// Initialize chat
function initChat() {
  // Any initialization logic can go here
}

// Start the chat
initChat();